This is the interview task for Briskit Agency
